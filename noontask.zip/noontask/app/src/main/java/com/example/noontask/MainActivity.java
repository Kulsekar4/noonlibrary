package com.example.noontask;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    TextView bookList,userbookdetails;
    EditText userName,bookName;
    Button getbtn,returnbtn,finebtn,userbookbtn,borrowedbtn;
    HashMap<String,Integer> Books;
    HashMap<String,String> User;
    HashMap<String,Integer> fine;
    HashMap<String, Date> date;
    HashMap<String, ArrayList<String>> borr;
    Date dt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

         bookList=(TextView)findViewById(R.id.booklist);

         userName=(EditText)findViewById(R.id.username);

         bookName=(EditText)findViewById(R.id.bookname);

         getbtn=(Button)findViewById(R.id.getbtn);

         returnbtn=(Button)findViewById(R.id.returnbtn);

         finebtn=(Button)findViewById(R.id.finebtn);

         userbookbtn=(Button)findViewById(R.id.userbooks);

         userbookdetails=(TextView)findViewById(R.id.userbookdetails);


        borrowedbtn=(Button)findViewById(R.id.borrowedbooks);

        Books=new HashMap<String,Integer>();
        User=new HashMap<String,String>();
        fine=new HashMap<String,Integer>();
        date=new HashMap<String,Date>();
        borr = new   HashMap<String,ArrayList<String>>();
        dt = new Date();
        Books.put("English-book",3);
        Books.put("Maths-book",4);
        Books.put("Science-book",2);
        Books.put("Social-book",6);
        Books.put("GK-book",10);

            System.out.println("\n1. Look at Books Available!");
            System.out.println("\n2. Get Books!");
            System.out.println("\n3. Know your fine!");
            System.out.println("\n4. Users and their books");
            System.out.println("\n5. Return your Books!");
            System.out.println("\n6.Books borrowed by persons!");
            System.out.println("\n7.Exit!");
            System.out.println("\nEnter your choice\n");


            BooksAvailable();

            getbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String name=userName.getText().toString();
                    String book=bookName.getText().toString();

                    User.put(name,book);
                    Books.put(book,Books.get(book)-1);
                    Calendar c = Calendar.getInstance();
                    c.setTime(dt);
                    c.add(Calendar.DATE, 2);
                    dt = c.getTime();
                    date.put(name,dt);
                    Toast.makeText(MainActivity.this, "Should return book before "+dt,Toast.LENGTH_LONG).show();
                    ArrayList<String> list ;
                    if(borr.get(book)==null){
                        list= new ArrayList<String>();
                    }else{
                        list =borr.get(book);
                    }

                    list.add(name);
                    borr.put(book,list);

                }
            });
                    finebtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            String name=userName.getText().toString();
                            if(fine.get(name)==null){
                                Toast.makeText(MainActivity.this, "No fine for you :)",Toast.LENGTH_LONG).show();
                            }else
                                Toast.makeText(MainActivity.this, "Your fine is !"+fine.get(name),Toast.LENGTH_LONG).show();

                        }
                    });


                    userbookbtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String output="";
                            for (Map.Entry<String,String> entry : User.entrySet()) {
                                String key = entry.getKey();
                                String value = entry.getValue();
                             output+=key+"--"+value+"\n";
                            }
                            userbookdetails.setText(output);
                        }
                    });

   returnbtn.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View view) {

           String name3=userName.getText().toString();
           User.remove(name3);
           if(dt.after(date.get(name3))){
               if(fine.get(name3)==null)
                   fine.put(name3,10);
               else
                   fine.put(name3,fine.get(name3)+10);
               Toast.makeText(MainActivity.this, "10 rs fine for you :)",Toast.LENGTH_LONG).show();
           }else{
               Toast.makeText(MainActivity.this, "No fine for you :)",Toast.LENGTH_LONG).show();
           }
       }
   });

     borrowedbtn.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {
             String output="";
             for (Map.Entry<String,ArrayList<String>> entry : borr.entrySet()) {
                 String key = entry.getKey();
                 ArrayList<String> value=entry.getValue();
                 output+=key+"--"+value+"\n";
             }
             userbookdetails.setText(output);
         }
     });

            }

    private void BooksAvailable() {
        String output="";
        for (Map.Entry<String,Integer> entry : Books.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            output+=key+"--"+value+"\n";
        }
        bookList.setText(output);
    }
}
